// ============================================================
// Firebase 設定ファイル
// ============================================================
// このファイルの中身を、Firebase コンソールから取得した
// 自分のプロジェクト設定に置き換えてください。
//
// 取得方法：セットアップガイド.md の「ステップ2」を参照
// ============================================================

import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// ↓↓↓ ここを書き換える ↓↓↓
const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
// ↑↑↑ ここまで書き換える ↑↑↑

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
